#pragma once
#include <windows.h>
#include "wtypes.h"
#include "dbt.h"
#include "CyAPI.h"
#include "Header.h"
#include "string.h"
#include "stdio.h"


/*
BOOL WINAPI DllMain(HINSTANCE hDLL, DWORD dwReason, LPVOID lpReserved)
{
	TMPClass *a;
	a	= new TMPClass();
	return true;
}
*/

LONG __stdcall SelectLarge(LONG A, LONG B)
{
	printf("a=%d,b=%d\r\n",A,B);
	return (A > B) ? A : B;
}
LONG __stdcall IncrementArray(LONG *data,LONG **pdata, LONG sizeX,LONG sizeY)
{
	int num = 0;
	int dnum = 0;
	int p = 0;
	int i;

	//2���z�������Ȃ�
	LONG *array = new long[sizeX];
	array =data;
	for (i = 0; i < sizeX; i++)
	{
		*(array++) = i;
	}
	data =array;
	return i;

#if 0
//	LONG *array = new long[sizeX];
	LONG **d_array = new long*[(sizeX)];
	for (i = 0; i < sizeX; i++){
		d_array[i] = new long[(sizeY)];
	}
//	array = data;
	d_array = pdata;
	for (i = 0; i < sizeX; i++)
	{
//		*(array++) = i;
//		num = num + array[i];
//		array[i] = ++array[i];
//		++array[i];
		for (k = 0; k < sizeY; k++){
			dnum = dnum + d_array[i][k];
			d_array[i][k] = 1+d_array[i][k];
			p++;
		}

	}


//	data = array;
	 pdata= d_array;
	for (i = 0; i < sizeX; ++i){
		delete[] d_array[i];
	}
	delete[] d_array;
	return k;
#endif
}
// name: write 4byte to COSMO
// summary : check VenderID(VID) ProductID(PID) (= input data)
// retuern  0= normal(OK), 1=not equal to(input ID) ,,3----> others error
//LONG __stdcall WriteUSBDevice(LONG *VID, LONG *PID, LONG *DCount)
LONG __stdcall TestUSB(LONG *VID, LONG *PID, LONG *data, LONG sizeX, LONG sizeY)
{
	//create instance of CCyUSBDevice
	CCyUSBDevice *USBDevice;
	USBDevice = new CCyUSBDevice(NULL, CYUSBDRV_GUID, 1);
	//OpenDevice
	LONG num = 0;
	int vID;
	int pID;
	int d = 0;
	int 	devices = USBDevice->DeviceCount();
	do{
		USBDevice->Open(d);
		vID = USBDevice->VendorID;
		pID = USBDevice->ProductID;
		d++;
	} while ((d<devices) && (vID != (*VID)) && (pID != (*PID)));
	if ((vID == (*VID)) && (pID == (*PID))){
		num = 0;
	}
	else if (d >= devices){
		num = 1;
	}
	else{
		num = 3;
	}
	*VID = vID;
	*PID = pID;

	if (num != 0){ return num; }//error number

	unsigned char buf[] = "Hello world";
	long length = 11;
//	long length = sizeX;
//	unsigned char *buf = new unsigned char [sizeX*4];
//	buf = (unsigned char*) data;

	bool err;
	err = false;
	if (USBDevice->BulkOutEndPt){
		err = USBDevice->BulkOutEndPt->XferData(buf, length);
	}
	if (err == true)num = 400;//OK
	else num = 200;//NG
	return num;
}

// name: select NewGenBoard
// summary : check VenderID(VID) ProductID(PID) (= input data)
// retuern  0= normal(OK), 1=not equal to(input ID) ,,3----> others error
LONG __stdcall OpenUSBDevice(LONG *VID, LONG *PID, LONG *DCount)
{
	//create instance of CCyUSBDevice
	CCyUSBDevice *USBDevice;
	USBDevice = new CCyUSBDevice(NULL,CYUSBDRV_GUID,1);
	//	CCyUSBDevice *USBDevice = new CCyUSBDevice(NULL);

	LONG num=0;
	int vID;
	int pID;
	int d = 0;
int 	devices = USBDevice->DeviceCount();
	do{
		USBDevice->Open(d);
		vID = USBDevice->VendorID;
		pID = USBDevice->ProductID;
		d++;
	} while ((d<devices) && (vID != (*VID)) && (pID != (*PID)));
	if ((vID == (*VID)) && (pID == (*PID))){
		num = 0;
	}
	else if (d >= devices){
		num = 1;
	}
	else{
		num = 3;
	}
	*VID = vID;
	*PID = pID;
	*DCount = devices;

	delete USBDevice;
	
	return num;
}
// name: write data to NewGenBoard
// summary : check VenderID(VID) ProductID(PID) (= input data)
// retuern  0= normal(OK), 1=not equal to(input ID) ,,3----> others error
LONG __stdcall WriteUSBDevice(LONG *VID, LONG *PID, UCHAR *data,LONG size, LONG GLV,LONG staddr)
{
	//create instance of CCyUSBDevice
	CCyUSBDevice *USBDevice;
	USBDevice = new CCyUSBDevice(NULL, CYUSBDRV_GUID, 1);
	//OpenDevice
	LONG num = 0;
	int vID;
	int pID;
	int d = 0;
	int 	devices = USBDevice->DeviceCount();
	do{
		USBDevice->Open(d);
		vID = USBDevice->VendorID;
		pID = USBDevice->ProductID;
		d++;
	} while ((d<devices) && (vID != (*VID)) && (pID != (*PID)));
	if ((vID == (*VID)) && (pID == (*PID))){
		num = 0;
	}
	else if (d >= devices){
		num = 1;
	}
	else{
		num = 3;
	}
	*VID = vID;
	*PID = pID;
	if (num != 0){ return num; }

//	int i;
	UCHAR *array = new unsigned char[size+1];
//	array = data;
	memcpy(array, data, size + 1);
	char buf[256];
	sprintf_s(buf, "WriteUSBDevice_memcpy(0x%8x 0x%8x %d)", array, data, size + 1);
	OutputDebugString(buf);

//	for (i = 0; i < size; i++)
//	{
//		*(array++) = i;
//	}
//	size *= 4;
	bool err;
	err = false;
	if (USBDevice->BulkOutEndPt){
		err = USBDevice->BulkOutEndPt->XferData((unsigned char*) array, size);
	}
	data = array;
	if (err = true)num =0;//OK
	else num = 200;//NG

	delete[] array;
	delete USBDevice;
	return num;
}

// name: select NewGenBoard For High Speed Communication
// retuern  0= normal(OK), 1=not equal to(input ID) ,,3----> others error
LONG __stdcall Only_newUSB(UCHAR *USBDevice1,LONG *size)
{
	//create instance of CCyUSBDevice
	CCyUSBDevice *USBDevice;
	USBDevice = new CCyUSBDevice(NULL, CYUSBDRV_GUID, 1);
	memcpy(USBDevice1, USBDevice, sizeof(USBDevice));
	//	CCyUSBDevice *USBDevice = new CCyUSBDevice(NULL);
	*size = (LONG) sizeof(USBDevice);
	delete USBDevice;
	return 0;
}


//_declspec(dllexport)CCyUSBDevice* GetCCyInstance()
CCyUSBDevice* _stdcall GetCCyInstance()
{
	char buf[256];
	CCyUSBDevice *USBDevice;
	USBDevice = new CCyUSBDevice(NULL, CYUSBDRV_GUID, 1);

	sprintf_s(buf, "GetCCyInstance(0x%8x)", USBDevice);
	OutputDebugString(buf);

	return USBDevice;
}


//_declspec(dllexport)void DeleteCCyInstance(CCyUSBDevice *arg)
LONG _stdcall DeleteCCyInstance(CCyUSBDevice *arg)
{
	delete arg;
	OutputDebugString("DeleteCCyInstance()");
	return 0;
}


// test retuern  0= normal(OK), 1=not equal to(input ID) ,,3----> others error
_declspec(dllexport)LONG Testcluster2(CCyUSBDevice *arg, LONG *outvID, LONG *outpID, LONG num)
{

	//	CCyUSBDevice *USBDevice;
	//	USBDevice = new CCyUSBDevice(NULL, CYUSBDRV_GUID, 1);
	LONG rtn=0;
	
	USHORT vID = 0xD2B;
	USHORT pID = 0x102;
	
	if (num > 0){
		arg->VendorID = vID;
		arg->ProductID = pID;
		*outvID = (LONG)arg->VendorID;
		*outpID = (LONG)arg->ProductID;
		rtn = 10;
	}else if(num < 0){
		*outvID = (LONG) arg->VendorID;
		*outpID = (LONG) arg->ProductID;
		rtn = -10;
	}
	else{
		*outvID = (LONG) 0xd2e;
		*outpID = (LONG) 0x103;
		rtn = 1000;
	}
	
	return rtn;
}
// test retuern  0= normal(OK), 1=not equal to(input ID) ,,3----> others error
//_declspec(dllexport)LONG OpenCCyUSB(CCyUSBDevice *arg, LONG *VID, LONG *PID, LONG *DCount)
LONG _stdcall OpenCCyUSB(CCyUSBDevice *arg, LONG *VID, LONG *PID, LONG *DCount)
{
	LONG num = -1;
	int vID;
	int pID;
	int d = 0;
	int 	devices = arg->DeviceCount();
	do{
		arg->Open(d);
		vID = arg->VendorID;
		pID = arg->ProductID;
		d++;
	} while ((d<devices) && (vID != (*VID)) && (pID != (*PID)));
	if ((vID == (*VID)) && (pID == (*PID))){
		num = 0;
	}
	else if (d >= devices){
		OutputDebugString("OpenCCyUSB(no COSMO)");
		num = 1;
	}
	else{
		OutputDebugString("OpenCCyUSB(no device)");
		num = 3;
	}
	*VID = vID;
	*PID = pID;
	*DCount = devices;

	return num;
}

// test retuern  0= normal(OK), 1=not equal to(input ID) ,,3----> others error
//_declspec(dllexport)LONG WriteCCyUSB(CCyUSBDevice *arg, UCHAR *data, LONG size, LONG GLV, LONG staddr)
LONG _stdcall WriteCCyUSB(CCyUSBDevice *arg, UCHAR *data, LONG size, LONG GLV, LONG staddr)
{

	LONG num=-1;
	UCHAR *array = new unsigned char[size+1];
//	array = data;

	char buf[256];

	sprintf_s(buf, "WriteCCyUSB_memcpy(0x%8x 0x%8x %d)", array, data, size+1);
	OutputDebugString(buf);

	memcpy(array, data, size+1);

	bool err;
	err = false;
	if (arg->BulkOutEndPt){
		err = arg->BulkOutEndPt->XferData((unsigned char*)array, size);
	}
//	data = array;
	if (err = true){
		num = 0;//OK
	}
	else{
		num = 200;//NG
		sprintf_s(buf, "err@XferData(%8x )", err);
		OutputDebugString(buf);
	}
	delete[] array;

	return num;
}

LONG __stdcall Test_MemError(UCHAR *data, LONG size, LONG GLV, LONG staddr)
{
	char buf[256];

	UCHAR *array = new unsigned char[size];
	sprintf_s(buf, "Test_MemError(0x%8x 0x%8x %d)", array, data, size);
	OutputDebugString(buf);


	memcpy(array, data, size);

	delete [] array;

	return 0;

}
//_declspec(dllexport)LONG TestMemoryError(UCHAR *data, LONG size, LONG GLV, LONG staddr)
LONG _stdcall TestMemoryError(UCHAR *data, LONG size, LONG GLV, LONG staddr)
{

	LONG num = -1;
	UCHAR *array = new unsigned char[size+1];
//	array = data;

	char buf[256];
	bool err;
	err = false;
//	if (arg->BulkOutEndPt){
	//	err = arg->BulkOutEndPt->XferData((unsigned char*)array, size);
	//}
	if (err = true)num = 0;//OK
	else num = 200;//NG

	sprintf_s(buf, "TestMemoryError(dst_0x%8x  scr_0x%8x %d )", array,data,size);
	OutputDebugString(buf);

#if 0
	array = data;
#else
	memcpy(array, data, size+1);
#endif

	delete[] array;

	return num;
}

UCHAR* __stdcall mallocMemory(LONG col)
{
	long size;
	char buf[256];
	if (col > 4096 ){
		return (UCHAR*)0;
	}
	size = col * 4096;//1col =4K
	UCHAR *array = new unsigned char[size];

	sprintf_s(buf, "malloc(0x%8x)", array);
	OutputDebugString(buf);

	return array;
}

LONG __stdcall CopyGLVData(UCHAR *dllmem, UCHAR *data, LONG col)
{
	if (col > 4096){
		return -1;
	}
	long size;
	size = col * 4096;//1col =4K
	
	char buf[256];
	sprintf_s(buf, "memcpy(0x%8x 0x%8x %d)", dllmem,data,size);
	OutputDebugString(buf);


	memcpy(dllmem,data,size);
//	printf("dllmem data size = %8x %8x %8x\r\n", dllmem,data,col);
//	printf("data[0][10] = %d %d\r\n", *data, *(data+10));
	return 0;

}
LONG __stdcall freeMemory(UCHAR *dllmem)
{
	char buf[256];
	sprintf_s(buf, "free(0x%8x)", dllmem);
	OutputDebugString(buf);
	delete [] dllmem;
	return 0;
}

LONG __stdcall TestOutputDebugString(UCHAR *data,LONG size)
{
	char buf[256];

//	sprintf_s(buf,"size=%d\r\n", size);
//	OutputDebugString(buf);

	sprintf_s(buf,"%d,(0x%8x)",*data,data);
	OutputDebugString(buf);


	return 0;
}




