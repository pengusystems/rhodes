class TMPClass
{
public:
	TMPClass(void)
	{
		int a1 = 2;
	}
	//TMPClass(HANDLE h, PUSB_ENDPOINT_DESCRIPTOR pEndPtDescriptor);


	UCHAR   ReqCode;
	WORD    Value;
	WORD    Index;

	bool Read(PUCHAR buf, LONG &len);
	bool Write(PUCHAR buf, LONG &len);
	int data(long a, long b);
};

